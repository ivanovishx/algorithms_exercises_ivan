#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */

class SnakeGame {

public:  
    SnakeGame(int width, int height);
    // SnakeGame(int width, int height, std::vector<std::vector<int> >& food);
    int move(std::string direction);
    void printMap();
    std::pair<int,int> newFood();

private:
    int score;
    std::vector <std::pair<int,int> > body;
    std::pair <int,int> head;
    std::vector<std::vector<int> >* food_;
    std::pair<int, int> food_now;
    int width_, height_;

    void moveBody(int add);
    int hitBody();




       
};
