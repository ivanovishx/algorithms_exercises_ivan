  #include "game.hpp"

        SnakeGame::SnakeGame(int width, int height) {
    // SnakeGame::SnakeGame(int width, int height, std::vector<std::vector<int> >& food) {
        score = 0;
        body.push_back(std::make_pair(0,0));
        // food_ = &food;
        head = std::make_pair(body.back().first, body.back().second);
        width_ = width;
        height_ = height;

        food_now = newFood();

        //Initialize random seed:
        srand (time(NULL));
    }
    
    int SnakeGame::move(std::string direction) {
        if (direction == "U")       head.second -= 1;   
        else if (direction == "D")  head.second += 1;   
        else if (direction == "L")  head.first -= 1;   
        else if (direction == "R")  head.first += 1;             
        
        // food_now = std::make_pair(food_[0][score][1], food_[0][score][0]);

        // if(food_[0].size() > 0 && food_[0].size() > score){
            if  (head == food_now) {
                score++; 
                moveBody(1);
                food_now = newFood();
            }
            else moveBody(0);
        // }
        // else moveBody(0);
        if (hitBody() || head.first < 0 || head.second < 0 || head.first >= width_  || head.second >= height_  ) 
            return -1; //GAME OVER
        
        return score;
    }

    void SnakeGame::moveBody(int add){
         body.push_back(head);
        if (add == 0) body.erase(body.begin());   
    }
    
    int SnakeGame::hitBody(){
            for (int i = 0; i < body.size() - 1; i++ ) 
                if (std::make_pair(head.first, head.second) == body[i] ) return 1;
        return 0;
    }
    

    void SnakeGame::printMap(){
    // std::vector<std::vector<char> > SnakeGame::printMap(){
        for (int i = 0; i < width_; i++){
            for (int j = 0; j < height_; ++j)
            {

                std::pair<int, int>temp = std::make_pair(i,j);
                if (temp == head)     std::cout<<"/";
                else if(find(body.begin(), body.end(), temp) != body.end()) std::cout<<".";
                else if (temp == food_now)     std::cout<<"$";
                // else if (temp == std::make_pair(food_[0][score][1], food_[0][score][0]))     std::cout<<"$";
                // if (make_pair(i,j) in body )    cout<<".";

                else std::cout<<"0";
                
            }
            std::cout << std::endl;
        }
    }

    std::pair<int, int> SnakeGame::newFood(){
        bool ok = false;
       
       
        std::pair<int, int> temp;
        while(!ok){

            int x = rand()%(width_);    
            // int x = rand()%(width_ - min + min) + min;
            int y = rand()%(height_);
            temp = std::make_pair(x,y);
            if(find(body.begin(), body.end(), temp) == body.end()) ok = true;
        }
        return temp;
    }






