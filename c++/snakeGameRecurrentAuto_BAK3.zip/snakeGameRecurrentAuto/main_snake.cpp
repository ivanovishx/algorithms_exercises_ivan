


#include <iostream>
#include "game.hpp"
// #include "ai.hpp"
using namespace std;

int main(int argc, char const *argv[])
{

	SnakeGame* game1 = new SnakeGame(7, 7);

	// std::vector<std::vector<int> > food = {{0,1},{0,2},{1,2},{2,2},{2,1},{2,0},{1,0}};
	// SnakeGame* game1 = new SnakeGame(7, 7, food);

	// for (int i = 0; i < 100; ++i)
	// {
		// std::pair<int, int> temp = game1->newFood();
		// std::cout <<temp.first << " | Y:"<<temp.second << std::endl;
	// }

	std::string movements = "RRDDLLUURRDDLLURULD";

	bool gameover = false;
	
	while(!gameover){

		movements = game1->find_food();
		std::cout<< "new movements:"<< movements <<endl;
		for ( auto c : movements){
			std::string s(1, c);
			std::cout << "----------Score:"<< game1->move(s) << endl<<endl;
			game1->printMap();
		}
	}


	/* code */
	return 0;
}